

def test_1():
    import checkStations
    assert (1==1)

