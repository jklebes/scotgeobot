from .context import checkStations

def test_1():
    assert (1==1)

